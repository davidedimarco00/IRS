Run with:

argos3 -c hellorobot.argos 


Just reduce the window containing the Lua editor and run the simulation by pressing the "play" button.